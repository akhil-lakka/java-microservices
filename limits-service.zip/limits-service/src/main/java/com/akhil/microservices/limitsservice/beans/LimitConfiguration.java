package com.akhil.microservices.limitsservice.beans;

public class LimitConfiguration {
	
	private int maximum;
	private int minimum;
	
	
	public int getMaximum() {
		return maximum;
	}
	
	protected LimitConfiguration() {
		
		
	}
	
	public LimitConfiguration(int maximum, int minimum) {
		super();
		this.maximum = maximum;
		this.minimum = minimum;
	}
	
	public int getMinimum() {
		return minimum;
	}
	
	
	
	

}
